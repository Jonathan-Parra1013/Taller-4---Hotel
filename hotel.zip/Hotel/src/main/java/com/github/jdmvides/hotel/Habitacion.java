
package com.github.jdmvides.hotel;


public class Habitacion {
    public int numero;
    public String tipo;
    public EstadoHabitacion estado;

    public Habitacion(int numero, String tipo) {
        this.numero = numero;
        this.tipo = tipo;
        this.estado = EstadoHabitacion.DISPONIBLE; 
    }
}
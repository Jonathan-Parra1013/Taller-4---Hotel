/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.github.jdmvides.hotel;

/**
 *
 * @author Usuario
 */
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import java.util.ArrayList;
import java.util.Scanner;

public class Hotel {
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);

        ArrayList<Habitacion> habitaciones = new ArrayList<>();
        ArrayList<Reserva> reservas = new ArrayList<>();

        habitaciones.add(new Habitacion(101, "Sencilla"));
        habitaciones.add(new Habitacion(102, "Doble"));
        habitaciones.add(new Habitacion(103, "Suite"));

        int opcion = 0;

        while (opcion != 5) {
            System.out.println("\n--- MENU HOTEL ---");
            System.out.println("1. Ver habitaciones disponibles");
            System.out.println("2. Hacer una reserva");
            System.out.println("3. Cambiar estado de habitacon (Admin)");
            System.out.println("4. Eliminar reserva");
            System.out.println("5. Salir");
            System.out.print("Elija una opcion: ");
            opcion = leer.nextInt();
            leer.nextLine(); 

            if (opcion == 1) {
                System.out.println("\n--- HABITACIONES DISPONIBLES ---");
                for (Habitacion h : habitaciones) {
                    if (h.estado == EstadoHabitacion.DISPONIBLE) {
                        System.out.println("Habitacion " + h.numero + " (" + h.tipo + ")");
                    }
                }

            } else if (opcion == 2) {
                System.out.println("\n--- NUEVA RESERVA ---");
                System.out.print("Nombre del huesped: ");
                String nombre = leer.nextLine();
                System.out.print("Documento: ");
                String doc = leer.nextLine();

                Huesped huesped = new Huesped(nombre, doc);

                System.out.print("Numero de habtacion a reservar: ");
                int numHab = leer.nextInt();
                leer.nextLine();

                Habitacion habEncontrada = null;
                for (Habitacion h : habitaciones) {
                    if (h.numero == numHab && h.estado == EstadoHabitacion.DISPONIBLE) {
                        habEncontrada = h;
                        break;
                    }
                }

                if (habEncontrada != null) {
                    System.out.print("Fecha de entrada (ej: 10/10/2026): ");
                    String entrada = leer.nextLine();
                    System.out.print("Fech de salida (ej: 15/10/2026): ");
                    String salida = leer.nextLine();

                    Reserva nuevaReserva = new Reserva(huesped, habEncontrada, entrada, salida);
                    reservas.add(nuevaReserva);

                    System.out.println(" Reserva realizada con exito!");
                } else {
                    System.out.println("Error: La habitacion no está disponible o no existe.");
                }
                
                } else if (opcion == 3) {
                    System.out.println("\n--- MODO ADMINISTRADOR ---");
                    System.out.print("Ingrese la contraseña de administrador: ");
                    String claveIngresada = leer.nextLine();

                    String claveCorrecta = "admin123"; 

                    if (claveIngresada.equals(claveCorrecta)) {
                        System.out.println("Acceso concedido");

                        System.out.print("Numero de habitacion: ");
                        int numHab = leer.nextInt();

                        Habitacion habEncontrada = null;
                        for (Habitacion h : habitaciones) {
                            if (h.numero == numHab) {
                                habEncontrada = h;
                                break;
                            }
                        }

                        if (habEncontrada != null) {
                            System.out.println("Seleccione el nuevo estado:");
                            System.out.println("1. DISPONIBLE");
                            System.out.println("2. MANTENIMIENTO");
                            int est = leer.nextInt();

                        if (est == 1) {
                            habEncontrada.estado = EstadoHabitacion.DISPONIBLE;
                        } else if (est == 2) {
                            habEncontrada.estado = EstadoHabitacion.MANTENIMIENTO;
                        }

                        System.out.println("Estado actualizado correctamente.");

                            System.out.println("Estado actualizado correctamente por" );
                        } else {
                            System.out.println("Habitacion no encontrada.");
                        }

                    } else {
                        System.out.println(" Error: Contraseña incorrecta. Acceso dengado.");
                    }
                }
            }
        System.out.println("Programa finalizado.");
        leer.close();
    }
}
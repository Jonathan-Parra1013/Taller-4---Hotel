/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.github.jdmvides.hotel;

/**
 *
 * @author Usuario
 */
public enum EstadoHabitacion {
    DISPONIBLE,
    OCUPADA,
    MANTENIMIENTO
}

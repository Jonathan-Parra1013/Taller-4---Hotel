/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.github.jdmvides.hotel;

/**
 *
 * @author Usuario
 */
import java.util.ArrayList;
import java.util.List;

public class Huesped {
    public String nombre;
    public String documento;

    public Huesped(String nombre, String documento) {
        this.nombre = nombre;
        this.documento = documento;
    }
}
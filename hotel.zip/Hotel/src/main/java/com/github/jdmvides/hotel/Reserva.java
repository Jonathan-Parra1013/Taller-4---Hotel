/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.github.jdmvides.hotel;

/**
 *
 * @author Usuario
 */
import java.time.LocalDate;

public class Reserva {
    public Huesped huesped;
    public Habitacion habitacion;
    public String fechaEntrada;
    public String fechaSalida;

    public Reserva(Huesped huesped, Habitacion habitacion, String fechaEntrada, String fechaSalida) {
        this.huesped = huesped;
        this.habitacion = habitacion;
        this.fechaEntrada = fechaEntrada;
        this.fechaSalida = fechaSalida;
        
        this.habitacion.estado = EstadoHabitacion.OCUPADA;
    }

    public void cancelar() {
        this.habitacion.estado = EstadoHabitacion.DISPONIBLE;
    }
}